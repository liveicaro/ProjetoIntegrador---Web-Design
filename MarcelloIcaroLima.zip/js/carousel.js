$('.myCarousel').carousel({
  interval: 2000
})