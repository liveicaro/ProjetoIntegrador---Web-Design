$('.carouselExampleSlidesOnly').carousel({
  interval: 2000
})